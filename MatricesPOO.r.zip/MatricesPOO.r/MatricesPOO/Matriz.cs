using System;

public class Matriz
{
    public int Filas { get; private set; }
    public int Columnas { get; private set; }
    private int[,] Datos;

    public Matriz(int filas, int columnas)
    {
        Filas = filas;
        Columnas = columnas;
        Datos = new int[filas, columnas];
    }

    public void LlenarAleatoriamente()
    {
        Random rnd = new Random();
        for (int i = 0; i < Filas; i++)
            for (int j = 0; j < Columnas; j++)
                Datos[i, j] = rnd.Next(1, 10);
    }

    public void Mostrar()
    {
        for (int i = 0; i < Filas; i++)
        {
            for (int j = 0; j < Columnas; j++)
                Console.Write(Datos[i, j] + "\t");
            Console.WriteLine();
        }
    }

    public Matriz Transpuesta()
    {
        Matriz t = new Matriz(Columnas, Filas);
        for (int i = 0; i < Filas; i++)
            for (int j = 0; j < Columnas; j++)
                t.Datos[j, i] = Datos[i, j];
        return t;
    }

    public Matriz Sumar(Matriz otra)
    {
        if (Filas != otra.Filas || Columnas != otra.Columnas)
            throw new InvalidOperationException("Las matrices deben tener las mismas dimensiones");

        Matriz resultado = new Matriz(Filas, Columnas);
        for (int i = 0; i < Filas; i++)
            for (int j = 0; j < Columnas; j++)
                resultado.Datos[i, j] = Datos[i, j] + otra.Datos[i, j];

        return resultado;
    }
// En esta parte del codigo agregamos la parte de la multiplicación, es igual a la suma solo cambiando su nombre y cambiando el signo de la operacion
    public Matriz Multiplicar(Matriz otra)
    {
        if (Filas != otra.Filas || Columnas != otra.Columnas)
            throw new InvalidOperationException("Las matrices deben tener las mismas dimensiones");

        Matriz resultado = new Matriz(Filas, Columnas);
        for (int i = 0; i < Filas; i++)
            for (int j = 0; j < Columnas; j++)
                resultado.Datos[i, j] = Datos[i, j] * otra.Datos[i, j];

        return resultado;
    }

}