﻿class Program
{
    static void Main()
    {
// En esta parte realizamos la parte de ingresar la dimension del arreglo 

        Console.Write("Ingrese la cantidad de Columnas: ");
        int Columnas = int.Parse(Console.ReadLine());

        Console.Write("Ingrese la cantidad de Filas: ");
        int Filas = int.Parse(Console.ReadLine());

// Aqui cambiamos el valor predeterminado de la matriz y lo pones segun los datos insertados

        Matriz m1 = new Matriz (Filas, Columnas);
        Console.WriteLine("Matriz 1:");
        m1.LlenarAleatoriamente();
        m1.Mostrar();

        Matriz m2 = new Matriz (Filas, Columnas);
        m2.LlenarAleatoriamente();
        Console.WriteLine("Matriz 2:");
        m2.Mostrar();

        Matriz suma = m1.Sumar(m2);
        Console.WriteLine("Suma:");
        suma.Mostrar();

        Matriz Multiplicar = m1.Multiplicar(m2);
        Console.WriteLine("Multiplicacion:");
        Multiplicar.Mostrar();

        Matriz transpuesta = m1.Transpuesta();
        Console.WriteLine("Transpuesta de la Matriz 1:");
        transpuesta.Mostrar();
    }
}